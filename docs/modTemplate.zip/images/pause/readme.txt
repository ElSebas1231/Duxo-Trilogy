place your mod logo or something you wanna see in the pause menu here! 
Use as reference the example in the folder.